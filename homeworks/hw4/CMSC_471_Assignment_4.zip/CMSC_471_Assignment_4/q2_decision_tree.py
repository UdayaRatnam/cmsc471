import pandas as pd

## To Do: Write the entropy(label) function
## Should find the information entropy of dataset (T) with class "label" i.e. Info(T)
def entropy(label):


## To Do: Write the information_gain(feature, label) function
## Should find the information gain of "feature"(X) on dataset (T) with class "label" i.e. Gain(X,T)
def information_gain(feature, label):


## To Do: Fill split(dataset, feature) function
## Should split the dataset on a feature
def split(dataset, feature):


## To Do: Fill find_best_split(dataset, label) function
## Should find the best feature to split the dataset on
## Should return best_feature, best_gain
def find_best_split(dataset, label):
    ## TO DO: Find the best feature to split the dataset

    return best_feature, best_gain


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    data = pd.read_csv('balloons.csv')

    best_feature, best_gain = find_best_split(data, "INFLATED")
    f = open("output_balloons.txt", "w")
    f.write("The Best Feature is {} with a Gain of : {}".format(best_feature, best_gain))
    f.close()